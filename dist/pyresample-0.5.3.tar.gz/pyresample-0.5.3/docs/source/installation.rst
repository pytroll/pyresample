Installing Pyresample
=====================
Pyresample depends on pyproj, numpy(>= 1.3), scipy(>= 0.7), multiprocessing 
(builtin package for Python > 2.5) and configobj.

The packages pyproj, numpy and scipy do not easy_install well so they will not be installed automatically 
when installing this package with easy_install.

Install pyproj and the correct versions of numpy and scipy on your system 
(refer to numpy and scipy installation instructions).

Package test
************
Test the package (requires nose):

.. code-block:: bash

	$ tar -zxvf pyresample-<version>.tar.gz
	$ cd pyresample-<version>
	$ nosetests
	
If all the tests passes the functionality of all pyresample functions on the system has been verified.

Package installation
********************
A sandbox environment can be created for pyresample using `Virtualenv <http://pypi.python.org/pypi/virtualenv>`_
 
Install Pyresample using setuptools:

.. code-block:: bash

	$ easy_install pyresample-<version>.tar.gz
 